<?php
declare(strict_types = 1);

namespace JackMD\scorefactory;

class ScoreFactoryException extends \Exception {}